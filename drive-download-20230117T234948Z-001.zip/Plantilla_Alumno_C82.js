console.log("My first console project");

            var first_name = "Ranbir";
            var last_name = "Kapoor";

/*
Concatenar el primer nombre y apellido para imprimir el nombre completo de la persona en la consola. 

Escribir la línea: "first_name.concat(last_name)"
*/
            var full_name =  ;
            console.log(full_name);

            var a = 10;
            var b = 5;
/*
Crear una variable llamada add y guardar el valor de la suma de a y b en esta variable.

Escribir: var add = a + b

Después, imprime la variable para mostrar el valor de la suma.

Escribir: console.log(add)
*/
            var add =   ;
            console.log( );

/*
Crear una variable llamada sub y guardar aquí la el valor de la resta de a y b.

Escribir: var sub = a - b

Después, imprimie el valor para mostrar el valor de la resta.

Escribir: console.log(sub)
*/
            var sub =   ;
            console.log( );

/*
Crear una variable llamada multiple y guardar aquí el valor de la multiplicación de a y b.

Escribir: var multiple = a * b

Después, imprime la variable para mostrar el valor de la multiplicación.

Escribir: console.log(multiple)
*/
            var multiple =   ;
            console.log();

            var divide = a / b ;
            console.log(divide);